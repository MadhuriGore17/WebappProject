$(document).ready(function(){
  $("form").submit(function(){
    alert("Details have been Submitted");
  });
});
