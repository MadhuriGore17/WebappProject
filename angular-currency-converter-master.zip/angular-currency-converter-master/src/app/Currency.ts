export interface Currency {
  rate: number;
  full_name: string;
  name: string;
  symbol: string;
}
